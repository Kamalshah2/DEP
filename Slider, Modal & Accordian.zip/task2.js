// Slider Functionality
let slideIndex = 0;
const slides = document.querySelectorAll('.slide');

function showSlide(index) {
    slides.forEach((slide, i) => {
        slide.classList.remove('active');
        if (i === index) {
            slide.classList.add('active');
        }
    });
}

function nextSlide() {
    slideIndex = (slideIndex + 1) % slides.length;
    showSlide(slideIndex);
}

function prevSlide() {
    slideIndex = (slideIndex - 1 + slides.length) % slides.length;
    showSlide(slideIndex);
}

// Automatically move to the next slide every 3 seconds
setInterval(nextSlide, 3000);

// Modal Functionality
function openModal(productId) {
    document.getElementById(`${productId}-modal`).style.display = 'flex';
}

function closeModal(productId) {
    document.getElementById(`${productId}-modal`).style.display = 'none';
}

// Accordion Functionality
const accordionHeaders = document.querySelectorAll('.accordion-header');

accordionHeaders.forEach(header => {
    header.addEventListener('click', () => {
        const accordionContent = header.nextElementSibling;

        // Toggle the active class
        header.classList.toggle('active');

        // Toggle the accordion content
        if (accordionContent.style.display === 'block') {
            accordionContent.style.display = 'none';
        } else {
            accordionContent.style.display = 'block';
        }

        // Close other accordions
        accordionHeaders.forEach(otherHeader => {
            if (otherHeader !== header) {
                otherHeader.classList.remove('active');
                otherHeader.nextElementSibling.style.display = 'none';
            }
        });
    });
});
