// Lazy loading script using IntersectionObserver
document.addEventListener("DOMContentLoaded", function() {
    const lazyImages = document.querySelectorAll("img.lazyload");
  
    if ("IntersectionObserver" in window) {
      let imageObserver = new IntersectionObserver(function(entries, observer) {
        entries.forEach(function(entry) {
          if (entry.isIntersecting) {
            let image = entry.target;
            image.src = image.dataset.src;
            image.classList.remove("lazyload");
            imageObserver.unobserve(image);
          }
        });
      });
  
      lazyImages.forEach(function(image) {
        imageObserver.observe(image);
      });
    } else {
      // Fallback for browsers without IntersectionObserver support
      lazyImages.forEach(function(image) {
        image.src = image.dataset.src;
      });
    }
  });
  